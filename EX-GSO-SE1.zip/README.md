# EX-GSO-SE1

Melih Z.
Niclas H.
Michael S.


Digitalisierungskonzept : https://github.com/mksaf/EX-GSO-SE1/blob/master/Unterlagen/Digitalisierungskonzept.txt

User Stories : https://github.com/mksaf/EX-GSO-SE1/blob/master/Unterlagen/User_Stories.txt

Priorisierung der User Stories : https://github.com/mksaf/EX-GSO-SE1/blob/master/Unterlagen/Priorisierung_der_User_Stories.txt

UML Use Case-Diagramm : https://github.com/mksaf/EX-GSO-SE1/blob/master/Unterlagen/UML_Use_Case-Diagramm.jpg

Robustheitsdiagramm : https://github.com/mksaf/EX-GSO-SE1/blob/master/Unterlagen/Robustheitsdiagramm.png

UML Klassendiagramme :  https://github.com/mksaf/EX-GSO-SE1/blob/master/Unterlagen/UML_Klassendiagramme.png
						https://github.com/mksaf/EX-GSO-SE1/blob/master/Unterlagen/UML_Klassendiagram_Usecase_Parken.png

UML Sequenzdiagramme : https://github.com/mksaf/EX-GSO-SE1/blob/master/Unterlagen/UML_Sequenzdiagramme.png

UML Aktivitätsdiagramme : https://github.com/mksaf/EX-GSO-SE1/blob/master/Unterlagen/UML_Aktivit%C3%A4tsdiagramm.PNG

UML Verteilungsdiagramm (deployment diagram) : https://github.com/mksaf/EX-GSO-SE1/blob/master/Unterlagen/UML_Verteilungsdiagramm.PNG

Java - Interfaces : !Keine!

lauffähige JUnit-Tests : https://github.com/mksaf/EX-GSO-SE1/tree/master/GSOCarHome/src

lauffähige Java - Klassen : https://github.com/mksaf/EX-GSO-SE1/tree/master/GSOCarHome/src

Verzeichnis der eingesetzten Patterns : https://github.com/mksaf/EX-GSO-SE1/blob/master/Unterlagen/Patterns.txt
