/**
 * @author michaelsafonov
 *
 */
public interface sequenceDataIF {
	String xData();
	boolean isWellSorted(String[] x) throws Exception;
}
